#pragma once

int fibonacci(int x);
int shift(int a, int b, bool shift_left);
bool isPrime(int a);
